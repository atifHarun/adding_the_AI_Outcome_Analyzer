# AI Outcome Analyzer — Integration Prompt

Paste the following prompt into your Replit AI agent:

---

Please integrate the AI Outcome Analyzer tool into this project. Here is exactly what needs to be done:

## 1. Install the openai package

Run: npm install openai

## 2. Update `server/routes.ts`

At the very top of the file, after the existing imports, add:

```ts
import path from "path";
import { fileURLToPath } from "url";
import { OpenAI } from "openai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let openai: OpenAI | null = null;
function getOpenAI(): OpenAI {
  if (!openai) {
    if (!process.env.OPENAI_API_KEY) {
      throw new Error("OPENAI_API_KEY environment variable is not set.");
    }
    openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  }
  return openai;
}

const AI_ANALYZER_REQUIRED_FIELDS = ["useCaseName", "systemType", "contextOfUse", "modelAutonomyLevel"];
const AI_ANALYZER_SYSTEM_TYPES = [
  "Text-based conversational AI",
  "Voice-based conversational AI",
  "Decision support AI",
  "Agent assist AI",
];
const AI_ANALYZER_AUTONOMY_LEVELS = [
  "Informational only",
  "Recommendation with human decision",
  "Action execution with human override",
  "Fully autonomous action",
];

function validateGeneratedJson(data: any): boolean {
  if (!data || typeof data !== "object") return false;
  for (const field of AI_ANALYZER_REQUIRED_FIELDS) {
    if (!(field in data)) return false;
  }
  if (!AI_ANALYZER_SYSTEM_TYPES.includes(data.systemType)) return false;
  if (!AI_ANALYZER_AUTONOMY_LEVELS.includes(data.modelAutonomyLevel)) return false;
  return true;
}
```

Then, inside the `registerRoutes` function, just before the closing brace, add these two new routes:

```ts
  // ── AI Outcome Analyzer: generate JSON from description ─────────────────
  app.post("/api/ai-analyzer/generate-json", async (req, res) => {
    try {
      const { description } = req.body;
      if (!description || typeof description !== "string" || !description.trim()) {
        return res.status(400).json({ message: "Description is required and cannot be empty." });
      }

      const prompt = `You are an expert in AI system design and schema validation. Convert the following free-text description of an AI system into a structured JSON object that strictly follows this schema:

{
  "useCaseName": "string - The name of the specific AI implementation",
  "systemType": "one of: Text-based conversational AI, Voice-based conversational AI, Decision support AI, Agent assist AI",
  "primaryFunction": "string (optional) - What the AI does",
  "contextOfUse": {
    "industry": "string - The industry",
    "environment": "one of: Internal, Customer-facing, Public"
  },
  "stakeholders": {
    "primaryUsers": ["array of strings"],
    "indirectlyAffectedParties": ["array of strings"],
    "oversightOwners": ["array of strings"]
  },
  "decisionsAndActions": {
    "decisionsMadeBySystem": ["array of strings"],
    "actionsExecutedAutomatically": ["array of strings"],
    "actionsRequiringHumanApproval": ["array of strings"]
  },
  "dataInputs": {
    "dataTypesUsed": ["array of strings"],
    "dataSources": ["array of strings"],
    "personalOrSensitiveData": boolean
  },
  "modelAutonomyLevel": "one of: Informational only, Recommendation with human decision, Action execution with human override, Fully autonomous action",
  "scaleAndReach": {
    "expectedNumberOfUsers": "string",
    "frequencyOfUse": "string",
    "geographicScope": "string"
  }
}

IMPORTANT RULES:
1. You MUST include all required fields: useCaseName, systemType, contextOfUse, modelAutonomyLevel
2. For enum fields, use EXACTLY the values specified above - no variations
3. Return ONLY valid JSON, no markdown, no explanation
4. Make reasonable inferences where information is not explicitly stated

Description: ${description}`;

      const response = await getOpenAI().chat.completions.create({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }],
        temperature: 0.3,
        response_format: { type: "json_object" },
      });

      const content = response.choices[0]?.message?.content;
      if (!content) throw new Error("No response from AI.");

      let parsed: any;
      try {
        parsed = JSON.parse(content);
      } catch {
        throw new Error("AI returned invalid JSON.");
      }

      if (!validateGeneratedJson(parsed)) {
        throw new Error("Generated JSON is missing required fields or has invalid enum values.");
      }

      res.json({ json: parsed });
    } catch (err: any) {
      res.status(400).json({ message: err.message || "Generation failed" });
    }
  });

  // ── AI Outcome Analyzer: analyze outcomes ────────────────────────────────
  app.post("/api/ai-analyzer/analyze", async (req, res) => {
    try {
      const body = req.body;
      if (!body || typeof body !== "object" || Object.keys(body).length === 0) {
        return res.status(400).json({ message: "Request body must be a non-empty JSON object." });
      }

      const systemPrompt = `You are an expert in AI ethics, governance, and risk assessment specializing in identifying potential outcomes of AI systems.

When given a structured AI use case definition, you must analyze and identify ALL potential outcomes across multiple dimensions.

Your response must follow this EXACT structure:

1. Positive outcomes
- List specific beneficial outcomes for each stakeholder group
- Include operational efficiencies, user benefits, business value

2. Negative outcomes  
- List specific harms, risks, and unintended consequences
- Include bias risks, privacy concerns, job displacement, over-reliance

3. Ethical considerations
- List specific ethical tensions and moral questions this AI raises
- Include fairness, transparency, accountability, consent issues

4. Legal and regulatory implications
- List specific laws, regulations, and compliance requirements relevant to this use case
- Include GDPR, sector-specific regulations, liability questions

5. Social impact
- List broader societal effects beyond direct users
- Include community effects, power dynamics, accessibility

Be specific to the use case described. Each section should have 4-6 bullet points. Use plain text, no bold markers.`;

      const userMessage = `Analyze the following AI use case and identify all potential outcomes:\n\n${JSON.stringify(body, null, 2)}`;

      const response = await getOpenAI().chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userMessage },
        ],
        temperature: 0.6,
        max_tokens: 1500,
      });

      const analysis = response.choices[0]?.message?.content;
      if (!analysis) throw new Error("No analysis returned from AI.");

      res.json({ analysis });
    } catch (err: any) {
      res.status(400).json({ message: err.message || "Analysis failed" });
    }
  });
```

## 3. Create new file `client/src/pages/AiAnalyzer.tsx`

Create this file with the full content provided in the zip package (file: `client/src/pages/AiAnalyzer.tsx`).

## 4. Update `client/src/App.tsx`

Add this import near the other page imports:
```ts
import AiAnalyzer from "./pages/AiAnalyzer";
```

Add this route inside the `<Switch>` block (before the NotFound catch-all):
```tsx
<Route path="/ai-analyzer" component={AiAnalyzer} />
```

## 5. Update `client/src/pages/Marketplace.tsx`

Find the Decision Outcomes tool definition and change its `route` from whatever it currently is to `/ai-analyzer`. It should look like:
```ts
{
  id: "decision-outcomes",
  title: "Decision Outcomes",
  route: "/ai-analyzer",
  featureFlag: "decision_outcomes" as const,
}
```

## 6. Update `client/src/config/featureFlags.ts`

Change `decision_outcomes` from `false` to `true`:
```ts
decision_outcomes: true,
```

## 7. Add the OPENAI_API_KEY secret

In Replit Secrets, add:
- Key: `OPENAI_API_KEY`
- Value: your OpenAI API key

## Done

After these changes, restart the dev server. The Decision Outcomes card in the Marketplace will show a "Run Tool" button that navigates to the AI Outcome Analyzer page at `/ai-analyzer`.
